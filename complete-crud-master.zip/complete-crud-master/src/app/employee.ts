export class Employee {
  // @ts-ignore
  id: number;
  // @ts-ignore
  firstName: string;
  // @ts-ignore
  lastName: string;
  // @ts-ignore
  emailId: string;
  // @ts-ignore
  active: boolean;


}
